package Teatro;

public class main {
	//entita passive il teatro
	//entita attive gli spettatori
	
	public static void main(String[] args) {
		teatro Teatro = new teatro(15,46);
		
        Thread[] spettatori = new Thread[7]; // numero spettatori.
        for (int i = 0; i < spettatori.length; i++) {
            spettatori[i] = new Thread(new spettatore(Teatro, "Spettatore " + (i + 1)));
        }
        
        for (Thread spettatore : spettatori) { 
            spettatore.start();
        }
        
        try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {}
        System.out.println("Lo spettacolo sta per iniziare");
        
        for (Thread spettatore : spettatori) {
            try {
				spettatore.join();
			} catch (InterruptedException e) {}
        }
        
        Teatro.mappaPosti();
        
        System.out.println("Posti disponibili: " + Teatro.postiavanzati());

	}

}