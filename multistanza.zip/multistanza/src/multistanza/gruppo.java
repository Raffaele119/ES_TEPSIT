package multistanza;

public class gruppo implements Runnable {
	private int timer;
	private int persone;
	private int posizionepista;
	private lista listaDiscoteca;
	private int numeropiste;
	
	public gruppo(int limitePersone, lista listaDiscoteca) {
        this.persone = (int)((Math.random() * (limitePersone - 2)) + 2);
        this.listaDiscoteca = listaDiscoteca;
        this.timer = (int)((Math.random() * (150 - 1)) + 1);
        this.numeropiste = listaDiscoteca.getlunghezza();
        this.posizionepista = posizionerandom(numeropiste);
    }
	
	private int posizionerandom(int max) {
		return (int)((Math.random() * (max)));
	}
	
	public void run() {//fa all'infinito l'incremento della lista con n persone e posizione della pista
		int volte = 0;
		do {
			listaDiscoteca.inc(persone, posizionepista);
			
			try {
				Thread.sleep(timer);
			}catch(InterruptedException e) {}
			
			listaDiscoteca.dec(persone, posizionepista);//decrementa lista 
			this.posizionepista = posizionerandom(numeropiste+1);//cambia posizione 
		}while(posizionepista != numeropiste && volte++ < 3);
	}
}
