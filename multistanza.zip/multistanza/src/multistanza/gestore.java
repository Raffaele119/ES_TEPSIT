package multistanza;

public class gestore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		lista listadisco = new lista(4);
		discoteca disco= new discoteca(listadisco);
		
		long delta = System.currentTimeMillis();
		
		while(true) {
			long currenttime = System.currentTimeMillis();
			if(currenttime - delta >= 500){
				delta = System.currentTimeMillis();
				disco.getpersone();
				
			}
			if(currenttime - delta >= 100)
				disco.entra(new gruppo(10, listadisco));
		}
	}

}
