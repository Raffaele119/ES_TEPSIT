package multistanza;

public class discoteca {
	private lista listadiscoteca;
	private int numeropiste;
	
	public discoteca(lista listadiscoteca) {
		this.listadiscoteca = listadiscoteca;
		this.numeropiste = listadiscoteca.getlunghezza();
	}
	
	public void entra(gruppo i) {
		Thread th = new Thread(i);
		th.start();
	}
	
	public void getpersone() {
		for(int i = 0 ; i< numeropiste; i++) {
			System.out.print("lista " + i + " -> " + listadiscoteca.get(i)+ " ");
			System.out.println();
		}
	}
}
