package multistanza;

public class lista {
	private int liste[];
	private int elementi;
	
	public lista(int elementi) {
		 liste = new int[elementi];
		 this.elementi = elementi;

	}
	public synchronized void inc(int numero, int indicelista) {
		liste[indicelista] += numero;
		
	}

	public synchronized void dec(int numero, int indicelista) {
		liste[indicelista] -= numero;
		
	}
	
	public int get(int indicelista) {
		return liste [indicelista];
	}
	
	public int getlunghezza() {
		return elementi;
	}
	
	
}
