/**
 * 
 */
/**
 * 
 */
module multistanza {
}