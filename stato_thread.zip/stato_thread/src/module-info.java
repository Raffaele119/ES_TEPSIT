/**
 * 
 */
/**
 * 
 */
module stato_thread {
}