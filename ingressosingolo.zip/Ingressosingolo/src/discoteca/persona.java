package discoteca;

public class persona implements Runnable{
	int timer;
	lista listaDiscoteca;

	public persona(lista listaDiscoteca) {
		this.timer = (int)((Math.random() * (1000 - 100)) + 100);
		this.listaDiscoteca = listaDiscoteca;
	}
	
	public void run() {
		listaDiscoteca.inc();
		
		try {
			Thread.sleep(timer);
		} catch (InterruptedException e) { }
		
		listaDiscoteca.dec();
	}
}